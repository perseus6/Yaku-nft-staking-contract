pub const NFT_STAKE_MAX_COUNT: usize = 50;
pub const DAY: i64 = 60 * 60 * 24; // 60 * 60 * 24; // 1 day
pub const GLOBAL_AUTHORITY_SEED: &str = "global-authority";
pub const VAULT_STAKE_SEED: &str = "vault-stake";
